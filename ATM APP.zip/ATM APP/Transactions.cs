﻿using System;

public static void main(string[] args)
{

    void printOptions()
    {
        Console.WriteLine("please choose options....");


    }
        






}





