﻿//[Nahom] [Diress] [11/28/2022]
// CIS162AD-FALL 2022
//CLASS 18882
//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace ATM_APP
{
     class AccountTest
    {
        static void Main(string[] args)
        {
            // Create a dictionary that maps usernames to passwords
            Dictionary<string, string> logins = new Dictionary<string, string>()
            {
                { "adm1", "9999" }
                , { "guest", "0000"}
                , {"user1", "1234"}
                , { "user2", "4321" }
            };

            Console.WriteLine("Bank application\n");

            // Display the login screen and menu options
            DisplayMenu(logins);
        }

        static void DisplayMenu(Dictionary<string, string> logins)
        {
            bool loginSuccessful = false;
            while (!loginSuccessful)    
            {
                //this code prompts the user to sign in 
                Console.Write("Enter Username: ");
                string userid = Console.ReadLine();
                Console.Write("Enter Pin Number: ");
                string pin = Console.ReadLine();

                if (pin.Length > 4)
                {
                    Console.Clear();
                    Console.WriteLine("Pin must be 4 characters in length.");
                    Console.WriteLine("press any key to continue");
                    Console.ReadLine();
                    Console.Clear() ;
                    Console.WriteLine("bank application\n");

                    
                }
                else
                {
                    
                }
                {
                    // Check if the entered login details are correct
                    if (logins.ContainsKey(userid) && logins[userid] == pin)
                     
                        
                    {
                        Console.Clear();
                        Console.WriteLine("Bank Application\n");
                        Console.WriteLine($"Welcome {userid}!\n");
                        loginSuccessful = true;

                        // Display the menu options
                        Console.WriteLine("1) Return to Login");
                        Console.WriteLine("2) Exit Application");
                        
                        Console.Write("\nEnter Your Menu Selection: ");


                        

                        // Get the menu option selected by the user
                        int choice = Convert.ToInt32(Console.ReadLine());
                        
                        
                        // Use a while loop to handle the "Return to Login" option
                        while (choice == 1)
                        {
                            Console.WriteLine("Log Out In Process\n\npress any key to continue.... ");
                            Console.ReadLine();
                            
                            Console.Clear();

                            // Display the login screen and menu options again
                            DisplayMenu(logins);
                            
                        }
                       
                        // Use a switch statement to handle the different menu options
                        switch (choice)
                        {
                            case 1:
                                // "Return to Login" option has already been handled in the while loop above
                                break;
                            case 2:
                                Console.Write("Press any Key to exit application...");
                                Console.ReadLine();
                                break;
                                case 3:
                                Console.WriteLine("add user");
                                Console.ReadLine();
                                break;

                                
                        }
                    }
                    else
                    {
                        
                        Console.WriteLine("Invalid username or pin. Please try again.");

                    }
                }
            }
        }
    }
}








