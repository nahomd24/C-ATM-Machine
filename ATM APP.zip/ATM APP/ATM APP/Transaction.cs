﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATM_APP
{
    internal class Transaction
    {
        class Menu
{
    // Track the login status
    public bool IsLoggedIn { get; set; }

    // Track the amount of money available at the bank
    public decimal CashBalance { get; set; } = 50000.00M;

    public Menu()
    {
        IsLoggedIn = false;
    }

    public void Login()
    {
        IsLoggedIn = true;
    }

    public void Logout()
    {
        IsLoggedIn = false;
    }
}

    }
   
}
